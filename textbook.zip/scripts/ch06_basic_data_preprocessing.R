# 6. 데이터 전처리 - 가공/처리

#-----
# 6-001.데이터 탐색에 사용할 데이터프레임 생성 
library(readxl)

df_px <- read_excel("data/excel_test.xlsx", sheet=2)
df_px

#
df_oc <- read.csv("data/data01.csv")
df_oc


#-----
# 6-002. head()함수를 사용한 데이터프레임의 위쪽데이터 확인
head(df_px)

#
head(df_px, 10)


#-----
# 6-003. tail()함수를 사용한 데이터프레임의 아래쪽데이터 확인
tail(df_px)

#
tail(df_px, 5)


#-----
# 6-004. dim()함수를 사용한 데이터프레임의 차원 확인
dim(df_px)


#-----
# 6-005. str()함수를 사용한 데이터프레임의 변수들의 속성을 확인
str(df_px)  


#-----
# 6-006. summary()함수를 사용한 요약통계량 확인
summary(df_oc)  

#
summary(df_oc$충돌)


#-----
# 6-007. data.frame()함수를 사용한 결과값 데이터프레임형태로 표현
data.frame(df_px)


#-----
# 6-008. names() 함수 사용
df_ghgs <- read.csv("data/1999-2018년_월간_온실가스.csv")

df_ghgs_new <- df_ghgs[, 2:9]
names(df_ghgs_new)

#
names(df_ghgs_new) <- c("관측일", "CO2_ppm", "CH4_ppm", "N2O_ppm", 
                        "CFC11_ppm", "CFC12_ppm","CFC113_ppm", "SF6_ppm")
names(df_ghgs_new)


#-----
# 6-009. dplyr패키지 설치 및 로드
install.packages("dplyr")

library(dplyr)


#-----
# 6-010. ggplot2패키지 설치 및 로드
install.packages("ggplot2")

library(ggplot2)

#-----
# 6-011. %>%연산자 
df_mpg <- mpg

#
df_mpg

# df_mpg데이터프레임 내용과 구조 파악:
head(df_mpg)  # 데이터프레임의 위쪽 데이터 6개 확인
tail(df_mpg)  # 데이터프레임의 위쪽 데이터 6개 확인
dim(df_mpg)  # 데이터프레임의 차원 확인 
str(df_mpg)  # 데이터프레임의 각 변수의 속성 확인
summary(df_mpg)  # 요약 통계량 확인

#
df_mpg %>% head


#-----
# 6-012. df_mpg데이터프레임에서 차종(class)이 "compact"데이터만 추출
df_mpg %>% filter(class == "compact")


#-----
# 6-013. 조건지정
# df_mpg데이터프레임에서 연료종류(fl)가 프리미엄("p")인 데이터만 추출
df_mpg %>% filter(fl == "p")

# df_mpg데이터프레임에서 고속도로 연비(hwy)가 35이상인 데이터만 추출
df_mpg %>% filter(hwy >= 35)


#-----
# 6-014. 조건이 여러 개일 경우 조건식 구성
# df_mpg에서 고속도로연비(hwy)가 30이상이고 도시연비(cty)가 30이상인 데이터
df_mpg %>% filter(hwy >= 30 & cty >= 30)

# df_mpg에서 차종(clsss)이 "pickup"이거나 "suv"인 데이터
df_mpg %>% filter(class == "pickup" | class == "suv")

# df_mpg에서 차종(clsss)이 "pickup"이거나 "suv"이거나 "2seater"인 데이터
df_mpg %>% filter(class == "pickup" | class == "suv" | class == "2seater")

df_mpg %>% filter(class %in% c("pickup", "suv", "2seater"))


#-----
# 6-015. 원소별 패턴검사 조건식
library(stringr)

# 자동차 모델명(model)에 "a4"가 포함된 경우
df_mpg %>% filter(str_detect(model, "a4"))


#-----
# 6-016. 변수 추출
# df_mpg데이터프레임에서 구동방식(drv), 도시연비(cty), 고속도로연비(hwy) 변수추출
df_mpg %>% select(drv, cty, hwy)

# trans변수를 제외하고 추출
df_mpg %>% select(-trans)

# model, year, trans, fl변수를 제외하고 추출
df_mpg %>% select(-c(model, year, trans, fl))


#-----
# 6-017. 변수 추출 방법
# 방법1: 데이터프레임변수$변수명
df_mpg$cyl

# 배기량(displ)과 고속도로연비(hwy)의 상관계수
cor(df_mpg$displ, df_mpg$hwy)

# 방법2: 데이터프레임변수["변수명"]
df_mpg["drv"]

# 방법3: 데이터프레임변수[, 열 번호]
# 인덱스번호가 5인 변수(cyl) 추출
df_mpg[, 5] 

# 인덱스번호가 2인 변수(model)와 5인 변수(cyl) 추출
df_mpg[, c(2, 5)]

# 인덱스번호가 2부터 5까지인 변수(model, displ, year, cyl) 추출
df_mpg[, 2:5]

# 방법4: 데이터프레임변수 %>% select(변수명)
df_mpg %>% select(fl)


#-----
# 6-018. 전처리함수 중첩
df_mpg %>%
  filter(class %in% c("compact", "suv")) %>%
  select(class, hwy)

# 결과를 변수에 저장
df_s_c <- df_mpg %>%
  filter(class %in% c("compact", "suv")) %>%
  select(class, hwy)


#-----
# 6-019. 정렬
# model명으로 오름차순 정렬
df_mpg %>% arrange(model)

# hwy 내림차순 정렬
df_mpg %>% arrange(desc(hwy))

# cyl 내림차순 정렬
df_mpg %>% arrange(-cyl)

# df_mpg을 class별 오름차순 정렬하고 각 class에서 cty를 내림차순으로 정렬후
# 10개의 데이터만 추출
df_mpg %>%  # df_mpg
  arrange(class, -cty) %>%  # class오름차순 1치정렬, cty 내림차순 2차 정렬
  head(10)  # 10개의 데이터 추출

# drv를 "f", "r", "4"순으로 정렬
df_mpg %>% 
  mutate(drv=factor(drv, levels=c("f", "r", "4"))) %>%
  arrange(drv)


#-----
# 6-020. gapminder로드 및 데이터 탐색
# gapminder 설치 및 로드
install.packages("gapminder")
library(gapminder)

# df_gap데이터프레임 생성
df_gap <- gapminder
df_gap

# df_gap데이터프레임 탐색
head(df_gap)
tail(df_gap)
dim(df_gap)
str(df_gap)

summary(df_gap)
names(df_gap)


#-----
# 6-021. 새변수 추가
df_gap %>% mutate(gdp = pop * gdpPercap)

# 방법2:  데이터프레임변수$새변수 <- 계산식
df_gap$gdp <- df_gap$pop * df_gap$gdpPercap
df_gap

#ifelse(조건, 참, 거짓) 함수를 사용한 새변수 추가
df_gap$sts <- ifelse(df_gap$pop>=1000000000, "인구과밀", "보통")
df_gap


#-----
# 6장 추가실습
# 실습1:  gdp변수 생성 후 위쪽 6건의 데이터를 화면에 출력해 보자.
df_gap %>% 
  mutate(gdp = pop * gdpPercap) %>% 
  head

# 실습2:  한국("Korea, Rep.")데이터만 추출 후 년도별 한국평균1인당gdp차이 계산
df_gap %>%
  filter(country == "Korea, Rep.") %>%
  mutate(diff_gdpPercap_mean = mean(gdpPercap) - gdpPercap)


#-----
# 6장 문제
# 문제1:  상태 변수 값 수정
df_c19_now <- read.csv("data/20211004기준_서울시_코로나19_확진자현황.csv")

head(df_c19_now)
tail(df_c19_now)
str(df_c19_now)

df_c19_now$상태 <- ifelse(df_c19_now$상태=="-", "입원", df_c19_now$상태)
df_c19_now$상태
#-----


#-----
# 6-022. 요약 통계치 산출
df_gap <- gapminder

df_gap %>%
  summarize(n_data=n(),  # 전체 데이터 수 
            median_lifeExp=median(lifeExp),  # 전체 기대수명 중위수
            mean_lifeExp=mean(lifeExp),  # 전체 기대수명 평균
            median_gdpPercap=median(gdpPercap),  # 전체 1인당gdp 중위수
            mean_gdpPercap=mean(gdpPercap))  # 전체 1인당gdp 평균


#-----
# 6-023. 그룹별 요약통계치
# df_gap에서 대륙별 인구수, 중위수기대수명, 평균기대수명, 중위수1인당gdp, 평균1인당gdp를 갖는  데이터프레임 생성
df_gap %>%
  group_by(continent) %>%  # 대륙별
  summarize(n_country=n(),
            median_lifeExp=median(lifeExp),
            mean_lifeExp=mean(lifeExp),
            median_gdpPercap=median(gdpPercap),
            mean_gdpPercap=mean(gdpPercap))

# df_mpg에서 차종별 구동방식별 자동차수, 평균도시연비, 평균고속도로연비를 갖는 데이터프레임 생성
df_mpg <- mpg

df_mpg %>%
  group_by(class, drv) %>%   # 차종별 구동방식별
  summarise(n_car=n(),
            mean_cty = mean(cty),
            mean_hwy = mean(hwy))

# df_mpg에서 차종이 "compact"이거나 "subcompact"인 데이터들 중 차종별 구동방식별 모델별 개수, 평균고속도로연비, 평균배기량을 갖는 데이터프레임 생성
df_mpg %>%
  filter(class %in% c("compact", "subcompact")) %>% 
  group_by(class, drv, model) %>% 
  summarise(n_car=n(),
            mean_cty = mean(cty),
            mean_hwy = mean(hwy),
            maen_displ = mean(displ))


#-----
library(dplyr)
library(ggplot2)


#-----
# 6-024. 조인 작업데이터 준비
# df_subway1데이터프레임 생성 및 탐색
df_subway1 <- read.csv("data/202002_서울지하철승하차인원수.csv")
head(df_subway1)
tail(df_subway1)
dim(df_subway1)
str(df_subway1)

# 노선별 요약통계치 데이터프레임 df1생성
df1 <- df_subway1 %>%
  group_by(노선명) %>%
  summarise(feb_승차총수=sum(승차총승객수),
            feb_하차총수=sum(하차총승객수))
df1

# df_subway2데이터프레임 생성 및 탐색
df_subway2 <- read.csv("data/202003_서울지하철승하차인원수.csv")
head(df_subway2)
tail(df_subway1)
dim(df_subway2)
str(df_subway2)

# 노선별 요약통계치 데이터프레임 df2생성
df2 <- df_subway2 %>%
  group_by(노선명) %>%
  summarise(mar_승차총수=sum(승차총승객수),
            mar_하차총수=sum(하차총승객수))
df2


#-----
# 6-025. 조인
# 노선명 변수를 기준으로 df1데이터프레임과 df2데이터프레임 결합, df_join에생성된 데이터프레임저장
df_join <- left_join(df1, df2, by="노선명") 
df_join


#-----
# 6장 추가실습
# 실습3: 지하철 노선별 하차승객이 가장많은 노선 6개 출력.
df_subway1 %>%
  group_by(노선명) %>%
  summarise(feb_승차총수=sum(승차총승객수),
            feb_하차총수=sum(하차총승객수)) %>%
  arrange(-feb_하차총수) %>%
  head

# 실습4:df_subway1에서 강남역만 얻어낸 결과, df_subway2에서 강남역만 얻어낸 결과
df_subway1 %>% filter(역명=="강남")
df_subway2 %>% filter(역명=="강남")

# 실습5: 지하철 역별 하차승객이 가장 많은 역 20개 출력.
df_subway1 %>%
  group_by(역명) %>%
  summarise(feb_역하차총수=sum(하차총승객수)) %>%
  arrange(-feb_역하차총수) %>%
  head(20)


#-----
library(readxl)


#-----
# 6-026. 바인딩 작업데이터 준비
df_accdata1 <- read_excel("data/2019년_광역시도_교통사고_사망자수.xlsx")
df_accdata2 <- read_excel("data/2020년_광역시도_교통사고_사망자수.xlsx")

head(df_accdata1)
head(df_accdata2)


#-----
# 6-027. df_accdata1, df_accdata2를 합친 새로운 데이터프레임 df_bind생성
df_bind <- bind_rows(df_accdata1, df_accdata2)
df_bind


#-----
# 6-028. 랜덤 샘플링
# df_bind데이터프레임에서 100개의 데이터를 랜덤 샘플링
sample_n(df_bind, 100)

# df_bind데이터프레임에서 5%(0.05)의 데이터를 랜덤 샘플링
sample_frac(df_bind, 0.05)


#-----
# 6-029. 고유행 추출
# df_bind데이터프레임에서 사고년도의 고유행 추출
distinct(df_bind, 사고년도)
