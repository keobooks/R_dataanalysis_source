### 3. R 기본 문법 ###

#-----
# 3-001.숫자변수 선언과 값 할당
x <- 5
# x변수 값 출력
x  


#-----
# 3-002.문자변수 선언과 값 할당
data <- "test"
# data변수 값 출력
data


#-----
# 3-003.변수 사용
x <- 5
y <- 5
# 값할당한 변수 연산에 사용후 결과 출력
x + y


#-----
# 3-004.변수 제거
remove(y)

# 제거된 변수를 사용하려고 하면 에러발생
y


#-----
# 3-005.변수 타입 확인 : numeric타입
val_x1 <- 5.0
class(val_x1)


#-----
# 3-006.변수 타입 확인 : integer타입
val_x2 <- 7L
class(val_x2)


#-----
# 3-007.변수 타입 확인 : character타입
val_str <- "good"
class(val_str)


#-----
# 3-008.변수 타입 확인 : logical타입
val_lg <- TRUE
class(val_lg)
# 
val_lg2 <- F
class(val_lg2)


#-----
# 3-009.변수 타입 확인 : complex타입
val_cmp <- 2 + 3i
class(val_cmp)


#-----
# 3-010.타입 변환 : integer타입을 numeric타입으로 변환
val_x1 <- 5.0
class(as.numeric(val_x1))


#-----
# 3-011.타입 변환 : character타입을 Date타입으로 변환
val_date <- "2021-12-30"
class(as.Date(val_date))


#-----
# 3-012.numeric타입인지 확인
val_x1 <- 5.0
is.numeric(val_x1)
#
val_str <- "winter"
is.numeric(val_str)


#-----
# 3-013.숫자 값을 갖는 벡터 선언
data_nums <- c(19, 95, 12, 30)
data_nums


#-----
# 3-014.문자 값을 갖는 벡터 선언
data_str <- c("bear", "tiger")
data_str


#-----
# 3-015.연속적인 숫자값을 갖는 벡터 선언
data_nums <- seq(1, 10, 2)
data_nums
#
data_nums <- seq(1, 10)
data_nums


#-----
# 3-016.벡터변수의 원소값 얻어냄
data_test <- c("a", "b", "c", "d", "e")
data_test

# 1개의 원소값 얻어냄
data_test[2]

# 연속된 여러 원소값 얻어냄
data_test[1:3]

# 비 연속적인 여러 원소 값 얻어내기
data_test[c(3, 5)]

# 마지막 원소 값 얻어내기
data_test[length(data_test)]


#-----
# 3-017.리스트타입 선언
list(12.345, "sun", c(2, 3), mean(seq(1:5)))
#
unlist(list(12.345, "sun", c(2, 3), mean(seq(1:5))))


#-----
# 3-018.행렬타입 선언
matrix(1:20, nrow=4, ncol=5)


#-----
# 3-019.배열타입 선언
array(1:20, dim=c(4, 4, 3))


#-----
# 3-020.데이터프레임 직접 만들기
df_a <- data.frame(x=c("서울", "경기", "강원"), y=c(1000, 1200, 200))
df_a
#
a <- c(1, 2, 3)
b <- c("a", "b", "c")
df <- data.frame(a, b)
df


#-----
# 3-021.csv파일을 읽어 데이터프레임 작성: read.csv()
df_1 <- read.csv("data/data01.csv")
df_1
# 한글이 깨질 경우
df_1 <- read.csv("data/data01.csv", encoding="cp949")
df_1


#-----
# 3-022.헤더없는 csv파일을 읽어 데이터프레임 작성: read.csv()
df_2 <- read.csv("data/data02.csv", head=F)
df_2
# 필드명 추가
names(df_2) <- c("시점", "총계", "충돌", "접촉", "좌초", "전복", "화재.폭발", "침몰", "행방불명", "기관손상", "추진기손상", "키손상", "속구손상", "조난",  "시설물손상", "인명사상", "안전운항저해", "해양오염", "기타")
df_2


#-----
# 3-022.readxl 패키지 설치
install.packages("readxl")

# readxl 패키지 로드
library(readxl)


#-----
# 3-023.엑셀파일을 읽어 데이터프레임 작성: read_excel()
df_ex <- read_excel("data/2020_seoul_gu_od.xlsx")
df_ex

# 필드명 제외하고 불러오기: col_names=F 옵션 사용
read_excel("data/2020_seoul_gu_od.xlsx", col_names=F)

# 특정시트 불러오기 - 시트번호
read_excel("data/excel_test.xlsx", sheet=2)

# 특정시트 불러오기 - 시트명
read_excel("data/excel_test.xlsx", sheet="2021년_광역시도_인구수")


#-----
# 3-024.대용량 csv파일 로드: fread()
library(data.table)
fread("data/big.csv")

# CSV파일을  데이터프레임 타입으로 읽어옴
fread("data/big.csv", data.table=FALSE)


#-----
# 3-025.사용자 정의 함수 만들기
# 매개변수 없는 사용자 정의 함수 만들기
fun_test <- function(){
  return(1)
}

# fun_test함수 사용
fun_test()

# 매개변수 있는 사용자 정의 함수 만들기
fun_test2 <- function(x, y){
  return(x * y)
}

# fun_test2함수 사용
fun_test2(5, 7)


##-----
# 3장 기본문법 추가사항 #
# 1. 데이터 로드 및 저장
# txt파일 로드 : 정형데이터
df_c <- read.table("data/data01.txt", header=TRUE, sep="")
df_c

# txt파일 로드 : 비정형데이터
news_data <- readLines("text/news2.txt", encoding="UTF-8")
news_data

# csv파일 로드 :정형데이터
df_c2 <- read.csv("data/data01.csv", head=T)
df_c2

# 엑셀 파일 로드 : 정형데이터
library(readxl)
df_t <- read_excel("data/2015-2020_sido_ta.xlsx")
df_t

# 파일 저장 : write.xxx()메소드 사용
# 웹 데이터 로드
url <- "http://people.stat.sc.edu/habing/courses/data/oildata.txt"
df_oil <- read.table(url, header=TRUE)

# txt파일로 저장 : 정형데이터
write.table(df_oil,"data/oildata.txt", quote=FALSE, append=FALSE)

# txt파일로 저장 : 비정형데이터
write(news_data, "text/datas.txt")

# csv파일로 저장
write.csv(df_oil, "data/data.csv", row.names=TRUE)

write.csv(df_oil, "data/data2.csv", row.names=TRUE, fileEncoding="cp949")

# 2. 패키지를 사용한 데이터 수집
# rvest 패키지를 사용한 웹페이지 테이블 데이터 수집

install.packages("selectr")
install.packages("xml2")
install.packages("rvest")

library(xml2)
library(rvest)
library(stringr)
library(dplyr)

pops <- read_html("https://en.wikipedia.org/wiki/World_population")
pops

wp <- pops %>% html_nodes(".wikitable")
wp

df_wp_raw <- as.data.frame(wp[3] %>% html_table())
df_wp_raw

class(df_wp_raw)

df_wp_raw[c(1:5)]

write.csv(df_wp_raw[c(1:5)],'data/pop.csv')

# 파일저장 후 엑셀에서 열어서 처리한 파일 pop1.csv
df_wp <- read.csv('data/pop1.csv')
df_wp

# 3. 그래픽스
# 산점도 작성 예
x <- 1:10 
y <- 1:10
plot(x, y)

# 막대그래프 작성 예
barplot(df_wp$Population, names.arg=df_wp$Country)

# 4. 흐름제어
# if문
x <- 5
if(x > 5){
  y <- 5
  z <- read.csv("a.csv")
}else{
  y <- 10
}

# for문
s <- 0
for(i in 1:5){
  s <- s + i
}
s

#
for(x in df_wp$Country){
  print(x)
}
