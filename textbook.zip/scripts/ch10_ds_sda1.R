# 10. 통계 분석에 필요한 기본개념

#-----
# 10-001. 필요패키지 설치 및 로드

# 주요 패키지 로드
library(readxl)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(gridExtra)


#-----
# 10-002. 코로나19사태 전과 후의 지하철 이용객수 차이 대응표본 t-test
# 데이터 로드
df_users <- read.csv("data/2019-2020년_월별지하철이용객수차이.csv")
df_users

# diff_2020_2019변수만 벡터로 추출해서 sub_users에 저장
sub_users <- df_users$diff_2020_2019
sub_users

# 수량형데이터 - 통계치 파악
summary(sub_users)

sd(sub_users)  # 표준편차

# 데이터 파악을 위한 시각화
par(mfrow=c(2, 2))  # 4개의 서브플롯
hist(sub_users)  # 히스토그램
boxplot(sub_users)  # 상자그림
qqnorm(sub_users); qqline(sub_users) # 정규분포의 Q-Q plot
hist(sub_users, prob=TRUE)  # 백분율 히스토그램
lines(density(sub_users), lty=3)  # 히스토그램에 추정선 분포 추가
dev.off()  # 그래프제거

# 파일로 저장시 사용
png("plots/c19_ds.png", 5.5, 4, units="in", pointsize=9, res=600)
par(mfrow=c(2, 2))  # 4개의 서브플롯
hist(sub_users)  # 히스토그램
boxplot(sub_users)
qqnorm(sub_users); qqline(sub_users)
hist(sub_users, prob=TRUE)
lines(density(sub_users), lty=3)
dev.off()

# 가설검정 
t.test(sub_users)


#-----
# 10-003. 전륜구동차와 4륜구동차 간의 도시주행 연비차이 비교 독립표본 t-test 
# 데이터 로드
library(ggplot2)
df_mpg <- mpg

# 데이터 탐색
head(df_mpg)
tail(df_mpg)
str(df_mpg)

# 구동방식이 f, 4인 데이터 중 구동방식과 도시주행연비 변수를 가진 df_s_c 생성
df_s_c <- df_mpg %>%
  filter(drv %in% c("f", "4")) %>%
  select(drv, cty)

df_s_c

# 구동방식(drv)이 전륜(f)과 4륜(4)인 데이터수 파악
table(df_s_c$drv)

# 전륜(f)데이터 도시주행연비(cty) 요약통계량
df_s_c %>% filter(drv=='f') %>% select(cty) %>% summary()

# 4륜(4)데이터 도시주행연비(cty) 요약통계량
df_s_c %>% filter(drv=='4') %>% select(cty) %>% summary()

# 구동방식(drv)별 도시주행연비(cty)비교 병렬상자그림
df_s_c %>% ggplot(aes(drv, cty)) + geom_boxplot()

# 파일로 저장시 사용
g <- df_s_c %>% ggplot(aes(drv, cty)) + geom_boxplot()
ggsave("plots/mpg_도시주행연비비교.png", g, width=6,
       height=4, units="in", dpi=600)

# 가설검정
t.test(data=df_s_c, cty ~ drv, var.equal=T)


#-----
# 10-004.지하철 2호선역별일별 하차승객수와 지하철 평균역별일별 하차승객수 비교
# 단일 표본 t-test

# 데이터 로드
df_sub <- read.csv("data/202002_서울지하철승하차인원수.csv")

# 데이터 탐색
head(df_sub)
tail(df_sub)
str(df_sub)

# 지하철 역별 일별 하차승객수 평균
tm_p <- (df_sub %>% summarise(mean_p=mean(하차총승객수)))$mean_p
tm_p

# 지하철 2호선 데이터만 추출후 df_sub_2에 저장
df_sub_2 <- df_sub %>% filter(노선명=="2호선")
df_sub_2

# df_sub_2의 하차총승객수 요약통계량
summary(df_sub_2$하차총승객수)

# 지하철 2호선 하차총승객수 상자그림
df_sub_2 %>% ggplot(aes(노선명, 하차총승객수)) + geom_boxplot()

# 가설검증
t.test(df_sub_2$하차총승객수, mu=tm_p)
















