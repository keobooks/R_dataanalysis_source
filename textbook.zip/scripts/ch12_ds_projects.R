# 12. 데이터분석 프로젝트

#-----
# 12-001. 공통사용 기본 패키지 로드
library(readxl)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(gridExtra)


# 1. 대한민국 인구변화 분석
#-----
# 12-002. 2020-2070_주요_인구지표 중위추계 데이터 로드
p50_m <- read_excel("data/2020-2070_주요_인구지표.xlsx",
                           sheet="2020-2070_주요_인구지표_중위_전처리")
p50_mc <- p50_m


#-----
# 12-003. 데이터 내용 및 구조파악
head(p50_m)
tail(p50_m)
dim(p50_m)
str(p50_m)
names(p50_m)


#-----
# 12-004. 요약통계량
summary(p50_m)

# 0-14세_인구, 15-64세_인구, 65세이상_인구 변수의 요약통계량
summary(p50_m[, 7:9])

# 0-14세_구성비, 15-64세_구성비, 65세이상_구성비 변수의 요약통계량
summary(p50_m[, 10:12])


#-----
# 12-005. 2020-2070년 총인구수 추이

# 년도, 총인구수 변수를 갖는 p50_m_part데이터프레임 생성
p50_m_part <- p50_m %>%
  select("년도", "총인구")

p50_m_part

# 2020-2070년 중위추계 총인구수 추이 시계열 그래프 작성
p50_m_part %>% 
  ggplot(aes(x=년도, y=총인구)) + geom_line()

# 2020-2070년 중위추계 총인구수 추이 시계열 및 선형회귀선추가 그래프 파일로저장
g1 <- p50_m_part %>% 
  ggplot(aes(x=년도, y=총인구)) + geom_line()

g2 <- p50_m_part %>% 
  ggplot(aes(x=년도, y=총인구)) + geom_line() +
  geom_smooth(method='lm', formula=y~x)

g <- arrangeGrob(g1, g2, ncol=2)

ggsave("plots/2020-2027_총인구수추이.png", plot=g, width=6, height=4,
       units="in", dpi=600)

# 2020-2070년 중위추계 총인구수 추이 10년 단위 그래프 파일로 저장
g1 <- p50_m_part %>% 
  filter(년도 < "2030-01-01") %>%
  ggplot(aes(x=년도, y=총인구)) + geom_line() +
  geom_smooth(method='lm', formula=y~x)
g2 <- p50_m_part %>% 
  filter(년도 >= "2030-01-01" & 년도 < "2040-01-01") %>%
  ggplot(aes(x=년도, y=총인구)) + geom_line() +
  geom_smooth(method='lm', formula=y~x)
g3 <- p50_m_part %>% 
  filter(년도 >= "2040-01-01" & 년도 < "2050-01-01") %>%
  ggplot(aes(x=년도, y=총인구)) + geom_line() +
  geom_smooth(method='lm', formula=y~x)
g4 <- p50_m_part %>% 
  filter(년도 >= "2050-01-01" & 년도 < "2060-01-01") %>%
  ggplot(aes(x=년도, y=총인구)) + geom_line() +
  geom_smooth(method='lm', formula=y~x)
g5 <- p50_m_part %>% 
  filter(년도 >= "2060-01-01" & 년도 < "2071-01-01") %>%
  ggplot(aes(x=년도, y=총인구)) + geom_line() +
  geom_smooth(method='lm', formula=y~x)

g <- arrangeGrob(g1, g2, g3, g4, g5, ncol=3)

ggsave("plots/2020-2027_총인구수추이_10년단위.png", plot=g, width=10, height=6,
       units="in", dpi=600)


#-----
# 12-006. 2020-2070년 총인구수 추이 고위추계 데이터 사용

# 2020-2070년 총인구수 고위추계 데이터 로드
p50_h <- read_excel("data/2020-2070_주요_인구지표.xlsx",
                    sheet="2020-2070_주요_인구지표_고위_전처리")
p50_hc <- p50_h

# 년도, 총인구수 변수를 갖는 p50_h_part데이터프레임 생성
p50_h_part <- p50_h %>%
  select("년도", "총인구")

# 2020-2070년 고위추계 총인구수 추이 시계열 및 선형회귀선추가 그래프 파일로저장
g1 <- p50_h_part %>% 
  ggplot(aes(x=년도, y=총인구)) + geom_line()

g2 <- p50_h_part %>% 
  ggplot(aes(x=년도, y=총인구)) + geom_line() +
  geom_smooth(method='lm', formula=y~x)

g <- arrangeGrob(g1, g2, ncol=2)

ggsave("plots/2020-2027_총인구수추이_고위추계.png", plot=g, width=6, height=4,
       units="in", dpi=600)


#-----
# 12-007. 2020-2070년 총인구수 추이 저위추계 데이터 사용

# 2020-2070년 총인구수 저위추계 데이터 로드
p50_l <- read_excel("data/2020-2070_주요_인구지표.xlsx",
                    sheet="2020-2070_주요_인구지표_저위_전처리")
p50_lc <- p50_l

# 년도, 총인구수 변수를 갖는 p50_l_part데이터프레임 생성
p50_l_part <- p50_l %>%
  select("년도", "총인구")

# 2020-2070년 저위추계 총인구수 추이 시계열 및 선형회귀선추가 그래프 파일로저장
g1 <- p50_l_part %>% 
  ggplot(aes(x=년도, y=총인구)) + geom_line()

g2 <- p50_l_part %>% 
  ggplot(aes(x=년도, y=총인구)) + geom_line() +
  geom_smooth(method='lm', formula=y~x)

g <- arrangeGrob(g1, g2, ncol=2)

ggsave("plots/2020-2027_총인구수추이_저위추계.png", plot=g, width=6, height=4,
       units="in", dpi=600)


#-----
# 12-008. 2020-2070년 중위추계 총인구수 단순회귀분석

# 년도 변수에서 년수만 추출해서 숫자데이터로 변환 후 year_val변수 값으로 p50_m_part데이터프레임에 추가
p50_m_part$year_val <- as.integer(substr(as.character(p50_m_part$년도), 1, 4))
p50_m_part

# year_val, 총인구 변수의 상관계수 
cor(p50_m_part$year_val, p50_m_part$총인구)

# year_val, 총인구 변수 단순 회귀분석
p50_m_part_lm <- lm(총인구 ~ year_val, data=p50_m_part)
p50_m_part_lm

# 모형적합도 검정
summary(p50_m_part_lm)


#-----
# 12-009. 2020-2070년 고위추계 총인구수 단순회귀분석
# p50_h_part데이터프레임에 year_val변수 추가
p50_h_part$year_val <- p50_m_part$year_val
p50_h_part

# year_val, 총인구 변수의 상관계수 
cor(p50_h_part$year_val, p50_h_part$총인구)

# year_val, 총인구 변수 단순 회귀분석
p50_h_part_lm <- lm(총인구 ~ year_val, data=p50_h_part)
p50_h_part_lm

# 모형적합도 검정
summary(p50_h_part_lm)


#-----
# 12-010. 2020-2070년 저위추계 총인구수 단순회귀분석
# p50_l_part데이터프레임에 year_val변수 추가
p50_l_part$year_val <- p50_m_part$year_val
p50_l_part

# year_val, 총인구 변수의 상관계수 
cor(p50_l_part$year_val, p50_l_part$총인구)

# year_val, 총인구 변수 단순 회귀분석
p50_l_part_lm <- lm(총인구 ~ year_val, data=p50_l_part)
p50_l_part_lm

# 모형적합도 검정
summary(p50_l_part_lm)


#-----
# 12-011. 2100년 중위추계 인구수 예측
# 2020-2070년 중위추계 단순회귀모형 p50_m_part_lm을 사용한 예측데이터와 예측오차
predict(p50_m_part_lm, se.fit=TRUE)

# 중위추계 단순회귀모형 p50_m_part_lm을 사용한 2071~2100년 예측데이터와 예측오차
predict(p50_m_part_lm, newdata=data.frame(year_val=c(2071:2100)),
        se.fit=TRUE)

# 고위추계 단순회귀모형 p50_m_part_lm을 사용한 2071~2100년 예측데이터와 예측오차
predict(p50_h_part_lm, newdata=data.frame(year_val=c(2071:2100)),
        se.fit=TRUE)

# 저위추계 단순회귀모형 p50_m_part_lm을 사용한 2071~2100년 예측데이터와 예측오차
predict(p50_l_part_lm, newdata=data.frame(year_val=c(2071:2100)),
        se.fit=TRUE)


#-----
# 12-012. 2020-2070년 중위추계 0-14세 인구구성비 추이
# 2020-2070년 중위추계 총인구수 데이터의 변수명 확인
names(p50_m)

# 2020-2070년 중위추계 총인구수 데이터에서 "년도", "0-14세_구성비", "15-64세_구성비", "65세이상_구성비" 만 추출해서 p50_m_per 데이터프레임 생성
p50_m_per <- p50_m %>%
  select("년도", "0-14세_구성비", "15-64세_구성비", "65세이상_구성비")

p50_m_per

# p50_m_per데이터프레임에서 년도별 `0-14세_구성비`를 시계열 + 산점도로 작성
p50_m_per %>% 
  ggplot(aes(x=년도, y=`0-14세_구성비`)) + geom_line() + geom_point()


#-----
# 12-013. 2020-2070년 중위추계 0-14세, 15-64세, 65세이상 인구구성비 추이

# 각 변수의 그래프 색상 지정. 범례 추가에 필요
colors <- c("0-14세_구성비"="green", "15-64세_구성비"="red", 
            "65세이상_구성비"= "orange")

colors

# p50_m_per데이터프레임 년도별 `0-14세_구성비`, `15-64세_구성비`, `65세이상_구성비`의 각각의 시계열을 1개의 그래프로 작성
p50_m_per %>% ggplot(aes(x=년도)) + 
  geom_line(aes(y=`0-14세_구성비`, color="0-14세_구성비"), size=1.5) + 
  geom_line(aes(y=`15-64세_구성비`, color="15-64세_구성비"), size=1.5) +
  geom_line(aes(y=`65세이상_구성비`, color="65세이상_구성비"), size=1.5) +
  scale_color_manual(values=colors) +
  labs(x="년도", y="인구구성비 추이", color="Legend") +
  ggtitle("2020-2070년 중위추계 인구구성비 추이") +
  theme(plot.title=element_text(size=20, face="bold", hjust=0.5))

# 2020-2070년 중위추계 인구구성비 추이.png로 저장
g <- p50_m_per %>% ggplot(aes(x=년도)) + 
  geom_line(aes(y=`0-14세_구성비`, color="0-14세_구성비"), size=1.5) + 
  geom_line(aes(y=`15-64세_구성비`, color="15-64세_구성비"), size=1.5) +
  geom_line(aes(y=`65세이상_구성비`, color="65세이상_구성비"), size=1.5) +
  scale_color_manual(values=colors) +
  labs(x="년도", y="인구구성비 추이", color="Legend") +
  ggtitle("2020-2070년 중위추계 인구구성비 추이") +
  theme(plot.title=element_text(size=16, face="bold", hjust=0.5))

ggsave("plots/2020-2070년 중위추계 인구구성비 추이.png", g, width=5, height=3, 
       units="in", dpi=600)


#-----
# 12-014. 2020-2070년 고위추계 0-14세, 15-64세, 65세이상 인구구성비 추이
p50_h_per <- p50_h %>%
  select("년도", "0-14세_구성비", "15-64세_구성비", "65세이상_구성비")

# 2020-2070년 고위추계 인구구성비 추이.png 시계열 그래프 파일 작성
g <- p50_h_per %>% ggplot(aes(x=년도)) + 
  geom_line(aes(y=`0-14세_구성비`, color="0-14세_구성비"), size=1.5) + 
  geom_line(aes(y=`15-64세_구성비`, color="15-64세_구성비"), size=1.5) +
  geom_line(aes(y=`65세이상_구성비`, color="65세이상_구성비"), size=1.5) +
  scale_color_manual(values=colors) +
  labs(x="년도", y="인구구성비 추이", color="Legend") +
  ggtitle("2020-2070년 고위추계 인구구성비 추이") +
  theme(plot.title=element_text(size=16, face="bold", hjust=0.5))

ggsave("plots/2020-2070년 고위추계 인구구성비 추이.png", g, width=5, height=3, 
       units="in", dpi=600)


#-----
# 12-015. 2020-2070년 저위추계 0-14세, 15-64세, 65세이상 인구구성비 추이
p50_l_per <- p50_l %>%
  select("년도", "0-14세_구성비", "15-64세_구성비", "65세이상_구성비")

# 2020-2070년 저위추계 인구구성비 추이.png 시계열 그래프 파일 작성
g <- p50_l_per %>% ggplot(aes(x=년도)) + 
  geom_line(aes(y=`0-14세_구성비`, color="0-14세_구성비"), size=1.5) + 
  geom_line(aes(y=`15-64세_구성비`, color="15-64세_구성비"), size=1.5) +
  geom_line(aes(y=`65세이상_구성비`, color="65세이상_구성비"), size=1.5) +
  scale_color_manual(values=colors) +
  labs(x="년도", y="인구구성비 추이", color="Legend") +
  ggtitle("2020-2070년 저위추계 인구구성비 추이") +
  theme(plot.title=element_text(size=16, face="bold", hjust=0.5))

ggsave("plots/2020-2070년 저위추계 인구구성비 추이.png", g, width=5, height=3, 
       units="in", dpi=600)


#-----
# 12-016. 2001-2020년 인구동태 주요지표 데이터 로드
ap_mi <- read_excel("data/2001-2020_인구동태_출생_사망_혼인.xlsx",
                    sheet="2001-2020_인구동태_전처리")
ap_mic <- ap_mi


#-----
# 12-017. ap_mi데이터프레임의 내용 및 구조파악
head(ap_mi)
tail(ap_mi)
dim(ap_mi)
str(ap_mi)
names(ap_mi)


#-----
# 12-018. ap_mi데이터프레임 요약통계량
summary(ap_mi)

# 출생아수, 혼인건수 변수의 요약통계량
summary(ap_mi[c("출생아수", "혼인건수")])


#-----
# 12-019. 2001-2020년 년도별 출생아수, 혼인건수 추이 서브플롯 작성
# 2001-2020년 년도별 출생아수 추이 시계열 그래프
g1 <- ap_mi %>% 
  ggplot(aes(x=년도, y=출생아수)) + geom_line(size=1.5) + 
  geom_smooth(method='lm', formula=y~x)

# 2001-2020년 년도별 혼인건수 추이 시계열 그래프
g2 <- ap_mi %>% 
  ggplot(aes(x=년도, y=혼인건수)) + geom_line(size=1.5) + 
  geom_smooth(method='lm', formula=y~x)

g <- arrangeGrob(g1, g2, ncol=2)

ggsave("plots/2001-2020_출생아수_혼인건수추이.png", plot=g, width=6, height=4,
       units="in", dpi=600)


#-----
# 12-020. 2001-2020년 출생아수, 혼인건수 추이 시계열 같은 그래프에 작성
# 각 변수의 그래프 색상 지정. 범례 추가에 필요
colors <- c("출생아수"="red", "혼인건수"="orange")

colors

# 각각의 시계열을 2001-2020_출생아수_혼인건수추이_결합.png로 저장
g <- ap_mi %>% ggplot(aes(x=년도)) + 
  geom_line(aes(y=출생아수, color="출생아수"), size=1.5) + 
  geom_line(aes(y=혼인건수, color="혼인건수"), size=1.5) +
  scale_color_manual(values=colors) +
  labs(x="년도", y="건수", color="Legend") +
  ggtitle("2001-2020년출생아수, 혼인건수 추이") +
  theme(plot.title=element_text(size=16, face="bold", hjust=0.5))

ggsave("plots/2001-2020_출생아수_혼인건수추이_결합.png", g, width=5, height=3, 
       units="in", dpi=600)


#-----
# 12-021. 2001-2020년 출생아수 상관분석

# ap_mi데이터프레임의 수량형변수 상관계수 구함
round(cor(ap_mi), 2)

# 출생아수와 관련있는 변수만 상관계수 구함
# "년도", "출생아수", "합계출산율", "혼인건수", "조혼인율_천명당", "이혼건수",     "조이혼율_천명당" 변수를 갖는 ap_mi_p 생성 
ap_mi_p <- ap_mi %>% 
  select("년도", "출생아수", "합계출산율", "혼인건수", "조혼인율_천명당", 
         "이혼건수" , "조이혼율_천명당")
ap_mi_p

# ap_mi_p데이터프레임의 수량형변수 상관계수
ap_mi_p_cor <- round(cor(ap_mi_p), 2)
ap_mi_p_cor

# ap_mi_p데이터프레임 상관행렬 히트맵
library(corrplot)

corrplot(ap_mi_p_cor, method="number")

# ap_mi_p데이터프레임 산점도 행렬
pairs(ap_mi_p)


#-----
# 12-022. 2001-2020년 혼인건수와 출생아수 관계 분석

# 혼인건수, 출생아수 변수의 상관계수 
cor(ap_mi_p$혼인건수, ap_mi_p$출생아수)

# 혼인건수와 출생아수 변수 단순회귀분석
ap_mi_p_lm <- lm(출생아수 ~ 혼인건수, data=ap_mi_p)
ap_mi_p_lm

# 모형적합도 검정
summary(ap_mi_p_lm)


#-----
# 12-023. 2001-2020년 조혼인율_천명당과 출생아수 관계 분석

# 조혼인율_천명당, 출생아수 변수의 상관계수 
cor(ap_mi_p$조혼인율_천명당, ap_mi_p$출생아수)

# 조혼인율_천명당과 출생아수 변수 단순회귀분석
ap_mi_p_lm2 <- lm(출생아수 ~ 조혼인율_천명당, data=ap_mi_p)
ap_mi_p_lm2

# 모형적합도 검정
summary(ap_mi_p_lm2)


#-----
# 12-024. 2021-2050년 출생아수 예측

# 년도와 출생아수 단순회귀분석
ap_mi_p_lm3 <- lm(출생아수 ~ 년도, data=ap_mi_p)
ap_mi_p_lm3

# 모형적합도 검정
summary(ap_mi_p_lm3)

# 년도와 출생아수 단순회귀모형 ap_mi_p_lm3을 사용한 2021-2050년 출생아수 예측데이터와 예측오차
predict(ap_mi_p_lm3, newdata=data.frame(년도=c(2021:2050)), se.fit=TRUE)


# 2. 연령대별 가구 재정변화 분석
#-----
# 12-025. 2017-2021년 자산부채소득현황 전체평균 데이터 로드
as5_m <- read_excel("data/2017-2021_가구주연령계층별_자산부채소득현황.xlsx",
                    sheet="자산부채소득현황_전체평균_전처리")
as5_mc <- as5_m


#-----
# 12-026. 데이터 내용 및 구조파악
head(as5_m)
tail(as5_m)
dim(as5_m)
str(as5_m)
names(as5_m)


#-----
# 12-027. 요약통계량
summary(as5_m)

# 전체_경상소득_전년도_만원, 부채보유_가구원수, 부채미보유_경상소득_전년도_만원 변수의 요약통계량
summary(as5_m[, c(4, 12, 20)])

# 전체_순자산액_만원, 부채보유_순자산액_만원, 부채미보유_순자산액_만원 변수의 요약통계량
summary(as5_m[, c(8, 16, 24)])


#-----
# 12-028. 2017-2021년 자산부채소득현황 시각화분석에 사용할 데이터프레임생성
as5_m_p <- as5_m %>% 
  select("년도", "전체_경상소득_전년도_만원", "전체_자산_만원", 
         "전체_부채_만원", "전체_순자산액_만원", 
         "부채보유_경상소득_전년도_만원", "부채보유_순자산액_만원",
         "부채미보유_경상소득_전년도_만원", "부채미보유_순자산액_만원")
as5_m_p

#-----
# 12-029. 2017-2021년 전체 평균 자산과 부채변화 추이 

colors <- c("전체_자산_만원"="green", "전체_부채_만원"="orange")

colors

# 2017-2021년 전체 평균 자산과 부채변화 추이 시계열 작성 후 파일로 저장
g <- as5_m_p %>% ggplot(aes(x=년도)) + 
  geom_line(aes(y=전체_자산_만원, color="전체_자산_만원"), size=1.5) + 
  geom_line(aes(y=전체_부채_만원, color="전체_부채_만원"), size=1.5) +
  scale_color_manual(values=colors) +
  labs(x="년도", y="금액", color="Legend") +
  ggtitle("2017-2021년 전체 평균 자산과 부채변화 추이") +
  theme(plot.title=element_text(size=16, face="bold", hjust=0.5))

ggsave("plots/2017-2021_전체평균자산_부채변화추이.png", g, width=5, height=3, 
       units="in", dpi=600)


#-----
# 12-030. 2017-2021년 부채보유 순자산액과 부채미보유 순자산액변화 추이
colors <- c("부채보유_순자산액_만원"="red", "부채미보유_순자산액_만원"="blue")

colors

# 2017-2021년 부채보유 및 부채미보유 순자산액변화 추이 시계열 작성 후 파일로 저장
g <- as5_m_p %>% ggplot(aes(x=년도)) + 
  geom_line(aes(y=부채보유_순자산액_만원, color="부채보유_순자산액_만원"), 
            size=1.5) + 
  geom_line(aes(y=부채미보유_순자산액_만원, color="부채미보유_순자산액_만원"), 
            size=1.5) +
  scale_color_manual(values=colors) +
  labs(x="년도", y="금액", color="Legend") +
  ggtitle("2017-2021년 부채보유, 부채미보유 순자산액변화 추이") +
  theme(plot.title=element_text(size=12, face="bold", hjust=0.5))

ggsave("plots/2017-2021_부채보유_부채미보유_순자산액변화추이.png", g, 
       width=5, height=3, units="in", dpi=600)


#-----
# 12-031. 2017-2021년 경상소득과 순자산액 관계 분석

# 경상소득과 순자산액 상관계수 
cor(as5_m_p$전체_경상소득_전년도_만원, as5_m_p$전체_순자산액_만원)

# 전체_경상소득_전년도_만원과 전체_순자산액_만원 변수 단순회귀분석
as5_m_p_lm <- lm(전체_순자산액_만원 ~ 전체_경상소득_전년도_만원, data=as5_m_p)
as5_m_p_lm

# 모형적합도 검정
summary(as5_m_p_lm)

# 경상소득과 순자산액 단순회귀모형 as5_m_p_lm을 사용한 
# 경상소득 6200~6700에 대한 순자산 예측데이터와 예측오차
predict(as5_m_p_lm, newdata=data.frame(
  전체_경상소득_전년도_만원=c(6200, 6300, 6400, 6500, 6700)), se.fit=TRUE)


#-----
# 12-032. 2017-2021년 연도별 경상소득과 자산 평균과 중위수 데이터 로드
as5_ia <- read_excel("data/2017-2021_가구주연령계층별_자산부채소득현황.xlsx",
                    sheet="연도별_자산부채소득현황_전체_전처리")
as5_iac <- as5_ia


#-----
# 12-033. 데이터 내용 및 구조파악
head(as5_ia)
tail(as5_ia)
dim(as5_ia)
str(as5_ia)
names(as5_ia)


#-----
# 12-034. 2021년 경상소득과 자산 평균, 중위수 비교
# 2021년 경상소득 평균, 중위수 비교
g1 <- as5_ia %>% 
  filter(년도==2021 & 항목 %in% c("평균_경상소득_전년도_만원", "중위수_경상소득_전년도_만원")) %>% 
  ggplot(aes(x=항목, y=금액)) + geom_col() +
  ggtitle("2021년 경상소득 평균 중위수 비교")+
  theme(plot.title=element_text(hjust=0.5))

# 2021년 자산 평균, 중위수 비교
g2 <- as5_ia %>% 
  filter(년도==2021 & 항목 %in% c("평균_자산_만원", "중위수_자산_만원")) %>% 
  ggplot(aes(x=항목, y=금액)) + geom_col()+
  ggtitle("2021년 자산 평균 중위수 비교") +
  theme(plot.title=element_text(hjust=0.5))

g <- arrangeGrob(g1, g2, ncol=2)
ggsave("plots/2021_경상소득과자산평균중위수_비교.png", g, width=8, height=4, 
       units="in", dpi=600)


#-----
# 12-035. 2017-2021년 경상소득과 자산 평균, 중위수 평균비교
# 2017-2021년 5년평균 경상소득과 자산 평균, 중위수
as5_ia_g <- as5_ia %>% 
  group_by(항목) %>%
  summarise(금액=mean(금액))
  
as5_ia_g

# 5년 경상소득 자산 평균, 중위수 비교
g1 <- as5_ia_g %>% 
  filter(항목 %in% 
             c("평균_경상소득_전년도_만원", "중위수_경상소득_전년도_만원")) %>% 
  ggplot(aes(x=항목, y=금액)) + geom_col() +
  ggtitle("2017-2021년간 평균 경상소득 평균 중위수 비교")+
  theme(plot.title=element_text(hjust=0.5))

# 5년 평균 자산 평균, 중위수 비교
g2 <- as5_ia_g %>% 
  filter(항목 %in% c("평균_자산_만원", "중위수_자산_만원")) %>% 
  ggplot(aes(x=항목, y=금액)) + geom_col() +
  ggtitle("2017-2021년간 평균 자산 평균 중위수 비교")+
  theme(plot.title=element_text(hjust=0.5))

g <- arrangeGrob(g1, g2, ncol=2)
ggsave("plots/2017-2021_평균_경상소득과자산_비교.png", g, width=8, height=4, 
       units="in", dpi=600)


#-----
# 12-036. 2017-2021년 연도별 경상소득과 자산 평균과 중위수 데이터 로드
as5_it <- read_excel("data/2017-2021_가구주연령계층별_자산부채소득현황.xlsx",
                     sheet="연도별_자산부채소득현황_전처리")
as5_itc <- as5_it

g1 <- as5_it %>% 
  filter(년도==2021 & 항목종류=="평균" & 항목 %in% 
      c("평균_경상소득_전년도_만원", "39세이하_경상소득_전년도_만원",   
        "29세이하_경상소득_전년도_만원", "30-39세_경상소득_전년도_만원",
        "40-49세_경상소득_전년도_만원", "50-59세_경상소득_전년도_만원",
        "60세이상_경상소득_전년도_만원", "65세이상_경상소득_전년도_만원")) %>%
  ggplot(aes(x=항목, y=값)) + geom_col() +
  ggtitle("2021년 연령대별 경상소득 평균 비교")+
  theme(plot.title=element_text(hjust=0.5), axis.text.x = element_text(angle=30, hjust=0.5))

g2 <- as5_it %>% 
  filter(년도==2021 & 항목종류=="평균" & 항목 %in% 
      c("평균_자산_만원", "39세이하_자산", "29세이하_자산", "30-39세_자산",
        "40-49세_자산", "50-59세_자산", "60세이상_자산", "65세이상_자산")) %>%
  ggplot(aes(x=항목, y=값)) + geom_col() +
  ggtitle("2021년 연령대별 자산 평균 비교")+
  theme(plot.title=element_text(hjust=0.5), axis.text.x = element_text(angle=30, hjust=0.7))

g <- arrangeGrob(g1, g2, ncol=2)
ggsave("plots/2021_연령대별_경상소득과자산평균_비교.png", g, width=8, height=4, 
       units="in", dpi=600)


#-----
# 12-037. 연령대별 재산의 건전성 및 소득 추이 비교용 데이터프레임 생성
# 데이터로드
as5_am <- read_excel("data/2017-2021_가구주연령계층별_자산부채소득현황.xlsx",
                    sheet="연령대별_자산부채소득현황_평균_전처리")
as5_amc <- as5_am


# 필요변수 선택 후 as5_am_p 데이터프레임 생성
as5_am_p <- as5_am %>%
  select("년도", "29세이하_경상소득_전년도_만원", "29세이하_부채_만원", 
         "30-39세_경상소득_전년도_만원", "30-39세_부채_만원",
         "40-49세_경상소득_전년도_만원", "40-49세_부채_만원" ,
         "50-59세_경상소득_전년도_만원", "50-59세_부채_만원",
         "60세이상_경상소득_전년도_만원", "60세이상_부채_만원",
         "65세이상_경상소득_전년도_만원", "65세이상_부채_만원")

# as5_am_p 데이터프레임의 변수명 변경
names(as5_am_p) <- c("년도", "20대_경상소득", "20대_부채", "30대_경상소득",
                     "30대_부채", "40대_경상소득", "40대_부채", "50대_경상소득",
                     "50대_부채","60세이상_경상소득", "60세이상_부채",
                     "65세이상_경상소득", "65세이상_부채")

# as5_am_p 데이터프레임에 새변수 추가
as5_am_p <- as5_am_p %>%
  mutate(`20대_경상소득대비부채`=`20대_경상소득`-`20대_부채`,
         `30대_경상소득대비부채`=`30대_경상소득`-`30대_부채`,
         `40대_경상소득대비부채`=`40대_경상소득`-`40대_부채`,
         `50대_경상소득대비부채`=`50대_경상소득`-`50대_부채`,
         `60세이상_경상소득대비부채`=`60세이상_경상소득`-`60세이상_부채`,
         `65세이상_경상소득대비부채`=`65세이상_경상소득`-`65세이상_부채`)

# as5_am_p 데이터프레임 표모양으로 확인
View(as5_am_p)


#-----
# 12-038. 2017-2021년 연령대별 부채 추이, 경상소득대비 부채 추이

# 2017-2021년 연령대별 부채 추이
colors <- c("20대_부채"="green", "30대_부채"="red", "40대_부채"="orange",
            "50대_부채"="black", "60세이상_부채"="grey", "65세이상_부채"="pink")

colors

# 연도별 연령대별 부채 추이
g1 <- as5_am_p %>% ggplot(aes(x=년도)) + 
  geom_line(aes(y=`20대_부채`, color="20대_부채"), size=1.5) + 
  geom_line(aes(y=`30대_부채`, color="30대_부채"), size=1.5) +
  geom_line(aes(y=`40대_부채`, color="40대_부채"), size=1.5) +
  geom_line(aes(y=`50대_부채`, color="50대_부채"), size=1.5) +
  geom_line(aes(y=`60세이상_부채`, color="60세이상_부채"), size=1.5) +
  geom_line(aes(y=`65세이상_부채`, color="65세이상_부채"), size=1.5) +
  scale_color_manual(values=colors) +
  labs(x="년도", y="금액", color="연령대") +
  ggtitle("2017-2021년 연령대별 부채 추이") +
  theme(plot.title=element_text(hjust=0.5))


# 2017-2021년 연령대별 경상소득대비부채 추이

colors <- c("20대_경상소득대비부채"="green", "30대_경상소득대비부채"="red",
            "40대_경상소득대비부채"="orange", "50대_경상소득대비부채"="black",
            "60세이상_경상소득대비부채"="grey", 
            "65세이상_경상소득대비부채"="pink")

colors

# 연도별 연령대별 경상소득대비부채 추이
g2 <- as5_am_p %>% ggplot(aes(x=년도)) + 
  geom_line(aes(y=`20대_경상소득대비부채`, color="20대_경상소득대비부채"), 
            size=1.5) + 
  geom_line(aes(y=`30대_경상소득대비부채`, color="30대_경상소득대비부채"), 
            size=1.5) +
  geom_line(aes(y=`40대_경상소득대비부채`, color="40대_경상소득대비부채"), 
            size=1.5) +
  geom_line(aes(y=`50대_경상소득대비부채`, color="50대_경상소득대비부채"), 
            size=1.5) +
  geom_line(aes(y=`60세이상_경상소득대비부채`, color="60세이상_경상소득대비부채"),
            size=1.5) +
  geom_line(aes(y=`65세이상_경상소득대비부채`, color="65세이상_경상소득대비부채"),
            size=1.5) +
  scale_color_manual(values=colors) +
  labs(x="년도", y="금액", color="연령대") +
  ggtitle("2017-2021년 연령대별 경상소득대비부채 추이") +
  theme(plot.title=element_text(hjust=0.5))

g <- arrangeGrob(g1, g2, ncol=2)
ggsave("plots/2017-2021_연령대별_부채_추이.png", g, width=12, height=4, 
       units="in", dpi=600)


#-----
# 12-039. 연령대별 소득과 부채 추이
# 데이터로드
as5_it <- read_excel("data/2017-2021_가구주연령계층별_자산부채소득현황.xlsx",
                     sheet="연도별_자산부채소득현황_전처리")
as5_itc <- as5_it

# 연령대별 소득 추이용 데이터프레임 생성
as5_it_p <- as5_it %>% 
  filter(년도==2021 & 항목종류=="평균" & 항목 %in% 
           c("29세이하_경상소득_전년도_만원", "30-39세_경상소득_전년도_만원",
             "40-49세_경상소득_전년도_만원", "50-59세_경상소득_전년도_만원",
             "60세이상_경상소득_전년도_만원", "65세이상_경상소득_전년도_만원"))
as5_it_p$연령대 <- c(20, 30, 40, 50, 60, 65)

# 연령대별 소득 추이 시계열
g1 <- as5_it_p %>%
  ggplot(aes(x=연령대, y=값)) + 
  geom_line(size=1.5) +
  ggtitle("2021년 연령대별 경상소득 추이")

# 연령대별 부채 추이용 데이터프레임 생성
as5_it_p2 <- as5_it %>% 
  filter(년도==2021 & 항목종류=="평균" & 항목 %in% 
             c("29세이하_부채_만원", "30-39세_부채_만원",
               "40-49세_부채_만원", "50-59세_부채_만원",
               "60세이상_부채_만원", "65세이상_부채_만원"))
as5_it_p2$연령대 <- c(20, 30, 40, 50, 60, 65)  

# 연령대별 부채 추이 시계열  
g2 <- as5_it_p2 %>%
  ggplot(aes(x=연령대, y=값)) + 
  geom_line(size=1.5) +
  ggtitle("2021년 연령대별 부채 추이")

g <- arrangeGrob(g1, g2, ncol=2)
ggsave("plots/2021_연령대별_경상소득_부채_추이.png", g, width=6, height=3, 
       units="in", dpi=600)
